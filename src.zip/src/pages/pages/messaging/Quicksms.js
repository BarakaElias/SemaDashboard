import React, { useContext, useState } from "react";
import { Helmet } from "react-helmet-async";
import NotyfContext from "../../../contexts/NotyfContext";
import { useSelector, RootStateOrAny } from "react-redux";
// import { retrieveSenderIDs } from "../../../redux/slices/senderids";
import { Button, Card, Col, Container, Form, Row } from "react-bootstrap";
import axios from "axios";
import AlertDialog from "../../../pages/ui/AlertDialog/AlertDialog";
import Timezones from "../../../utils/timezones";
import { GetDeliveryReport } from "./deliveryStatus";

const QuickSMS = () => {
  const notyf = useContext(NotyfContext);
  const user = useSelector((state: RootStateOrAny) => state.user.value);
  const sender_ids = useSelector(
    (state: RootStateOrAny) => state.sender_ids.values
  );

  const [quickState, setQuickState] = useState({
    quickSMSForm: {
      sms_type: {
        required: true,
        value: "T",
        hasError: false,
      },
      encoding: {
        required: true,
        value: "T",
        hasError: false,
      },
      phonenumber: {
        required: true,
        value: "",
        hasError: false,
      },
      sender_id: {
        required: true,
        value: "",
        hasError: false,
      },
      textmessage: {
        required: true,
        value: "",
        hasError: false,
        characters: "0",
      },
      smsTemplate: {
        required: false,
        value: "",
        hasError: false,
      },
      smsRTL: {
        required: false,
        value: false,
        hasError: false,
      },
      smsSchedule: {
        required: false,
        value: "",
        hasError: false,
      },
      smsJobname: {
        required: false,
        value: "",
        hasError: false,
      },
    },
    smsStatus: {
      hasAlert: false,
      alertType: "",
      alertMessage: "",
    },
    dateAndTime: {
      required: false,
      value: "",
      hasError: false,
    },
    timeZone: {
      required: false,
      value: "",
      hasError: false,
    },
    alertOpen: false,
  });

  const alertDialogContent = {
    type: "certainty",
    title: "Are you sure?",
    message:
      "Your message will be sent in 1 Part & contains " +
      quickState.quickSMSForm["textmessage"].characters +
      "  characters. Do you want to send sms?",
  };

  const closeAlertModal = () => {
    setQuickState({ alertOpen: false, quickSMSForm: quickState.quickSMSForm });
  };

  const openAlertModal = () => {
    setQuickState({ alertOpen: true, quickSMSForm: quickState.quickSMSForm });
  };

  const checkValidity = (value, isRequired) => {
    let isValid = true;
    if (isRequired) {
      isValid = value.trim() === "";
      return isValid;
    }
    return !isValid;
  };

  const inputChangedHandler = (event, inputIdentifier) => {
    const updatedQuickSMSForm = { ...quickState.quickSMSForm };
    const updatedFormElement = { ...updatedQuickSMSForm[inputIdentifier] };
    updatedFormElement.value = event.target.value;
    updatedFormElement.hasError = checkValidity(
      updatedFormElement.value,
      updatedFormElement.required
    );
    if (inputIdentifier === "textmessage") {
      updatedFormElement.characters = updatedFormElement.value.length;
    }
    updatedQuickSMSForm[inputIdentifier] = updatedFormElement;
    setQuickState({ quickSMSForm: updatedQuickSMSForm });
  };

  const sendSMSHandler = (event) => {
    event.preventDefault();
    const formData = {};
    let params = {};
    for (let formElementIdentifier in quickState.quickSMSForm) {
      if (quickState.quickSMSForm[formElementIdentifier].hasError) {
        return;
      }
      formData[formElementIdentifier] =
        quickState.quickSMSForm[formElementIdentifier].value;

      params = {
        api_id: user.api_id,
        api_password: user.api_password,
        sms_type: formData["sms_type"],
        encoding: formData["encoding"],
        sender_id: formData["sender_id"],
        phonenumber: formData["phonenumber"],
        textmessage: formData["textmessage"],
      };
    }
    axios
      .get("https://api.sema.co.tz/api/SendSMS", { params: params })
      .then((response) => {
        const status = response.data["status"];
        if (status === "S") {
          notyf.open({
            type: "success",
            message: "SMS submitted succesfully!",
            duration: 10000,
            ripple: true,
            dismissible: true,
            position: { x: "center", y: "top" },
          });
          GetDeliveryReport(response.data["message_id"]);
        } else if (status === "F") {
          notyf.open({
            type: "danger",
            message: "SMS failed to submit! Check network connection",
            duration: 10000,
            ripple: true,
            dismissible: true,
            position: { x: "center", y: "top" },
          });
          notyf.close();
        }
      })
      .catch((err) => {
        notyf.open({
          type: "warning",
          message: "Message not sent",
          duration: 10000,
          ripple: true,
          dismissible: true,
          position: { x: "center", y: "top" },
        });
      });
    setQuickState({
      alertOpen: false,
      quickSMSForm: quickState.quickSMSForm,
    });
  };

  let dialog = quickState.alertOpen ? (
    <AlertDialog
      content={alertDialogContent}
      closeAlertFunc={closeAlertModal}
      sendSMSFunc={sendSMSHandler}
    />
  ) : null;

  const scheduleForm =
    quickState.quickSMSForm["smsSchedule"].value === "yes" ? (
      <Row>
        <Col>
          <Form.Group className="mb-3">
            <Form.Label>Select Timezone</Form.Label>
            <Form.Select
              onChange={(event) => this.inputChangedHandler(event, "timeZone")}
              type="text"
              name="smsType"
            >
              {Timezones.map((timezone) => (
                <option>{timezone.offset + " " + timezone.name}</option>
              ))}
            </Form.Select>
          </Form.Group>
        </Col>
        <Col>
          <Form.Group className="mb-3">
            <Form.Label>Select Date & Time</Form.Label>
            <Form.Control
              onChange={(event) =>
                this.inputChangedHandler(event, "dateAndTime")
              }
              type="datetime-local"
              min="11/07/2021 19:30 21"
            />
          </Form.Group>
        </Col>
      </Row>
    ) : null;

  return (
    <React.Fragment>
      {dialog}
      <Helmet title="Quick SMS" />
      <Container fluid className="p-0">
        <h1 className="h3 mb-3">Quick SMS</h1>
        {/* <p> {this.state.quickSMSForm}</p> */}
        <Card>
          <Card.Header>
            <Card.Title tag="h5">Send a quick SMS</Card.Title>
            <h6 className="card-subtitle text-muted">
              Some subtitle goes here
            </h6>
          </Card.Header>
          <Card.Body>
            <Form>
              <Row>
                <Col md={4}>
                  <Form.Group className="mb-3">
                    <Form.Label>SMS Type</Form.Label>
                    <Form.Select
                      onChange={(event) =>
                        inputChangedHandler(event, "sms_type")
                      }
                      type="text"
                      name="smsType"
                    >
                      <option value="T">Transactional</option>
                      <option value="P">Promotional</option>
                    </Form.Select>
                  </Form.Group>
                </Col>
                <Col md={4}>
                  <Form.Group className="mb-3">
                    <Form.Label>Select Sender Id</Form.Label>

                    <Form.Select
                      onChange={(event) =>
                        inputChangedHandler(event, "sender_id")
                      }
                      name="senderId"
                    >
                      <option />
                      {sender_ids.map((sender_id) => (
                        <option
                          key={sender_id.sender_id}
                          value={sender_id.sender_id}
                        >
                          {sender_id.sender_id}
                        </option>
                      ))}
                    </Form.Select>
                    <Form.Check
                      type="checkbox"
                      id="checkbox"
                      label="Open Sender ID"
                    />
                  </Form.Group>
                </Col>
                <Col md={4}>
                  <Form.Group className="mb-3">
                    <Form.Label>Select SMS Encoding</Form.Label>

                    <Form.Select
                      onChange={(event) =>
                        inputChangedHandler(event, "encoding")
                      }
                      name="smsEncoding"
                    >
                      <option value="T">Text (Used for only English)</option>
                      <option value="U">Unicode (Used for all languages</option>
                      <option value="FS">
                        Flash SMS (Used only with English
                      </option>
                      <option value="UFS">
                        Unicode Flash SMS (Use for all languages)
                      </option>
                    </Form.Select>
                  </Form.Group>
                </Col>
              </Row>
              <Form.Group className="mb-3">
                <Form.Label>
                  Enter Phone Numbers (Enter One Number Per Line. Max 100
                  Numbers)
                </Form.Label>
                <Form.Control
                  as="textarea"
                  required
                  name="phoneNumbers"
                  onChange={(event) =>
                    inputChangedHandler(event, "phonenumber")
                  }
                  placeholder="Enter phone number one below the other with country code Eg: 255624323232"
                />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Select Template</Form.Label>

                <Form.Select
                  onChange={(event) =>
                    inputChangedHandler(event, "smsTemplate")
                  }
                  name="smsTemplate"
                >
                  <option />
                  <option>...</option>
                </Form.Select>
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Enter Message Text</Form.Label>
                <Form.Check
                  onChange={(event) => inputChangedHandler(event, "smsRTL")}
                  type="checkbox"
                  name="smsRTL"
                  id="smsRTL"
                  label="Enable RTL Format"
                />
                <p>
                  Contains{" "}
                  <strong>
                    {quickState.quickSMSForm["textmessage"].characters}
                  </strong>{" "}
                  characters
                </p>

                <Form.Control
                  as="textarea"
                  name="smsMessage"
                  required
                  placeholder="Enter Message Text"
                  onChange={(event) =>
                    inputChangedHandler(event, "textmessage")
                  }
                />
                <ul>
                  <li>Encoding: GSM_7BIT</li>
                  <li>
                    Length: {quickState.quickSMSForm["textmessage"].characters}
                  </li>
                  <li>Messages: 0</li>
                  <li>Per Message: 160</li>
                  <li>
                    Remainig:
                    {160 - quickState.quickSMSForm["textmessage"].characters}
                  </li>
                </ul>
              </Form.Group>
              <Row>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Schedule Message</Form.Label>

                    <Form.Select
                      onChange={(event) =>
                        inputChangedHandler(event, "smsSchedule")
                      }
                      name="smsSchedule"
                    >
                      <option>No</option>
                      <option value="yes">Yes</option>
                    </Form.Select>
                  </Form.Group>
                  {scheduleForm}
                </Col>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Job Name (optional)</Form.Label>
                    <Form.Control
                      type="text"
                      name="smsJobname"
                      onChange={(event) =>
                        inputChangedHandler(event, "smsJobname")
                      }
                      placeholder="Please enter a job name"
                    />
                  </Form.Group>
                </Col>
              </Row>
              <Button size="lg" onClick={openAlertModal} variant="primary">
                Send SMS
              </Button>
            </Form>
          </Card.Body>
        </Card>
      </Container>
    </React.Fragment>
  );
};

export default QuickSMS;
