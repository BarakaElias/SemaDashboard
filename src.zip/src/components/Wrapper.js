import React from "react";

const Wrapper = ({ children }) => <div className="wrapper">{children}</div>;

export default Wrapper;
